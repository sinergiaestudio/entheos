/* ANATHEOS Demo Local v0.1 — native uncompressed DICOM browser viewer.
 * Operates only on File/Blob bytes provided by the user or localhost package.
 * No remote API or data telemetry. Experimental; not medical/diagnostic.
 * Cornerstone3D compatibility is tracked in separate G2a browser experiments.
 */
const $=id=>document.getElementById(id);
const state={series:[],current:null,index:0,wlCenter:350,wlWidth:850,brightness:0,contrast:100,zoom:1,panX:0,panY:0,loadGeneration:0,source:'',imageKey:'',lastPixels:null};
const LONG=new Set(['OB','OD','OF','OL','OV','OW','SQ','UC','UR','UT','UN']);
const NUMTAG=new Set([0x00280002,0x00280010,0x00280011,0x00280100,0x00280101,0x00280102,0x00280103,0x00280006]);
const TAGS=new Map([[0x00020010,'syntax'],[0x00080060,'modality'],[0x0008103e,'description'],[0x00080016,'sopClass'],[0x0020000e,'seriesUid'],[0x00200013,'instance'],[0x00200032,'ipp'],[0x00200037,'iop'],[0x00280002,'samples'],[0x00280004,'photo'],[0x00280008,'frames'],[0x00280010,'rows'],[0x00280011,'columns'],[0x00280030,'spacing'],[0x00280100,'bitsAllocated'],[0x00280101,'bitsStored'],[0x00280102,'highBit'],[0x00280103,'signed'],[0x00281052,'intercept'],[0x00281053,'slope'],[0x00281050,'dicomCenter'],[0x00281051,'dicomWidth'],[0x7fe00010,'pixels']]);
const UTF8=new TextDecoder('utf-8');
function stringVal(bytes){return UTF8.decode(bytes).replace(/[\x00 ]+$/g,'').trim();}
function numericList(s){return (s||'').split('\\').map(Number).filter(Number.isFinite);}
function hasDicm(buffer){return buffer.byteLength>=132&&String.fromCharCode(...new Uint8Array(buffer,128,4))==='DICM';}
function readDicom(buffer,name){
 const view=new DataView(buffer),u8=new Uint8Array(buffer);
 if(!hasDicm(buffer))throw Error('No contiene cabecera DICOM Part 10 (DICM)');
 let offset=132,syntax='',meta={},pixelOffset=-1,pixelLength=0;
 while(offset+8<=buffer.byteLength){
  const group=view.getUint16(offset,true),element=view.getUint16(offset+2,true),tag=(group*65536+element)>>>0;
  offset+=4;
  const explicit=(group===2 || syntax!=='1.2.840.10008.1.2');let vr='',length=0;
  if(explicit){vr=String.fromCharCode(u8[offset],u8[offset+1]);offset+=2;
   if(LONG.has(vr)){if(offset+6>buffer.byteLength)throw Error('Campo DICOM incompleto');offset+=2;length=view.getUint32(offset,true);offset+=4;}
   else{length=view.getUint16(offset,true);offset+=2;}
  }else{length=view.getUint32(offset,true);offset+=4;}
  if(length===0xffffffff){if(tag===0x7fe00010)throw Error('Transfer Syntax encapsulada o comprimida: no compatible con este visor local');throw Error('Secuencia DICOM de longitud indefinida: versión local no compatible');}
  if(offset+length>buffer.byteLength)throw Error('Campo DICOM incompleto o longitud fuera del archivo');
  const key=TAGS.get(tag);
  if(tag===0x7fe00010){pixelOffset=offset;pixelLength=length;break;}
  if(key){
   if(NUMTAG.has(tag)&&length===2)meta[key]=view.getUint16(offset,true);
   else if(length<4096)meta[key]=stringVal(u8.subarray(offset,offset+length));
   if(tag===0x00020010)syntax=meta.syntax;
  }
  offset+=length;
 }
 if(pixelOffset<0)throw Error('No se encontró Pixel Data (7FE0,0010)');
 if(!['1.2.840.10008.1.2.1','1.2.840.10008.1.2'].includes(meta.syntax))throw Error('Transfer Syntax '+(meta.syntax||'desconocida')+' no compatible con Demo v0.1');
 if(meta.frames&&Number(meta.frames)>1)throw Error('Instancia multiframe: todavía no compatible con esta demo local');
 if(meta.samples!==1||!['MONOCHROME2','MONOCHROME1'].includes(meta.photo))throw Error('Solo se admiten muestras DICOM monocromáticas');
 if(meta.bitsAllocated!==16||!(meta.bitsStored>=1&&meta.bitsStored<=16))throw Error('Profundidad de bits no compatible (se requieren 16 bits asignados)');
 if(!(meta.rows>0&&meta.columns>0&&meta.rows<=8192&&meta.columns<=8192))throw Error('Matriz DICOM inválida');
 const count=meta.rows*meta.columns;
 if(pixelLength<count*2)throw Error('Pixel Data contiene menos bytes de los esperados');
 const pixelBytes=new DataView(buffer,pixelOffset,count*2),bits=meta.bitsStored,mask=bits===16?0xffff:(1<<bits)-1;
 const values=new Int32Array(count);
 for(let i=0;i<count;i++){let v=pixelBytes.getUint16(i*2,true)&mask;
  if(meta.signed===1&&v&(1<<(bits-1)))v-=1<<bits;
  values[i]=v;
 }
 const ipp=numericList(meta.ipp),iop=numericList(meta.iop),spacing=numericList(meta.spacing);
 if(ipp.length!==3||iop.length!==6||spacing.length!==2||spacing.some(s=>s<=0))throw Error('Faltan IPP, IOP o PixelSpacing válidos para ordenar la serie');
 return {...meta,filename:name,ipp,iop,spacing,values,pixelCount:count,
  slope:Number(meta.slope)||1,intercept:Number(meta.intercept)||0};
}
// CRC32 detects corrupted ZIP members before parsing as medical images.
const CRC_TABLE=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;t[n]=c>>>0;}return t;})();
function crc32(data){let c=0xffffffff;for(let i=0;i<data.length;i++)c=CRC_TABLE[(c^data[i])&255]^(c>>>8);return (c^0xffffffff)>>>0;}
function listZip(buffer){
 const v=new DataView(buffer),arr=new Uint8Array(buffer),last=Math.max(0,arr.length-65557);let eocd=-1;
 for(let i=arr.length-22;i>=last;i--)if(v.getUint32(i,true)===0x06054b50){eocd=i;break;}
 if(eocd<0)throw Error('No se encontró el índice central del ZIP');
 const num=v.getUint16(eocd+10,true),start=v.getUint32(eocd+16,true);
 if(num===0xffff||start===0xffffffff)throw Error('ZIP64 todavía no compatible');
 if(num>12000)throw Error('ZIP excede el límite local de archivos');
 let p=start,entries=[];
 for(let i=0;i<num;i++){
  if(p+46>arr.length||v.getUint32(p,true)!==0x02014b50)throw Error('Índice central ZIP inconsistente');
  const flags=v.getUint16(p+8,true),method=v.getUint16(p+10,true),crc=v.getUint32(p+16,true),compressed=v.getUint32(p+20,true),uncompressed=v.getUint32(p+24,true),nlen=v.getUint16(p+28,true),xlen=v.getUint16(p+30,true),clen=v.getUint16(p+32,true),local=v.getUint32(p+42,true);
  const name=UTF8.decode(arr.subarray(p+46,p+46+nlen));
  if(!name.endsWith('/'))entries.push({name,flags,method,crc,compressed,uncompressed,local});
  p+=46+nlen+xlen+clen;
 }
 return entries;
}
async function unpackMember(buffer,entry){
 const v=new DataView(buffer),arr=new Uint8Array(buffer),p=entry.local;
 if(v.getUint32(p,true)!==0x04034b50)throw Error('Encabezado local ZIP no válido');
 if(entry.flags&1)throw Error('ZIP cifrado no permitido');
 const dataStart=p+30+v.getUint16(p+26,true)+v.getUint16(p+28,true);
 if(dataStart+entry.compressed>buffer.byteLength)throw Error('ZIP truncado');
 const comp=arr.subarray(dataStart,dataStart+entry.compressed);
 let result;
 if(entry.method===0)result=new Uint8Array(comp);
 else if(entry.method===8){
  if(typeof DecompressionStream==='undefined')throw Error('Tu navegador no admite ZIP; extraé la carpeta DICOM y abrila');
  result=new Uint8Array(await new Response(new Blob([comp]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
 }else throw Error('Método de compresión ZIP no compatible: '+entry.method);
 if(result.byteLength!==entry.uncompressed||crc32(result)!==entry.crc)throw Error('CRC incorrecto o longitud inválida del ZIP');
 return result;
}
function vecCross(a,b){return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}
function dot(a,b){return a.reduce((sum,v,i)=>sum+v*b[i],0);}
function orientCheck(a,b){return a.iop.every((v,k)=>Math.abs(v-b.iop[k])<0.0003);}
function clean(){state.current=null;state.series=[];state.index=0;state.imageKey='';state.lastPixels=null;state.source='';state.panX=0;state.panY=0;state.zoom=1;updateControls();render();}
function cancelCurrent(){state.loadGeneration++;$('loading').hidden=true;}
function showLoad(detail,progress=0){$('loading').hidden=false;$('loadingDetail').textContent=detail;$('loadingProgress').style.width=progress+'%';}
function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('visible');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('visible'),4200);}
const yieldUI=()=>new Promise(ok=>requestAnimationFrame(()=>setTimeout(ok,0)));
function warningsDisplay(errors,notes){const w=$('warnings');w.replaceChildren();if(!errors.length&&!notes.length){w.textContent='Archivos comprobados. Sin errores de lectura.';w.classList.add('oktext');return;}
 w.classList.remove('oktext');for(let msg of [...errors.slice(0,6).map(s=>'ERROR · '+s),...notes.slice(0,6)]){const p=document.createElement('p');p.textContent=msg;if(msg.startsWith('ERROR'))p.classList.add('error');w.append(p);}if(errors.length>6){const p=document.createElement('p');p.textContent=`+ ${errors.length-6} errores adicionales`;w.append(p);}}
async function loadBuffer(buffer,source,gen){
 let files=[];const errors=[];let notes=[];const entries=listZip(buffer);
 let selected=entries;
 const nested=entries.filter(e=>/\.zip$/i.test(e.name));
 const dicoms=entries.filter(e=>!e.name.includes('__MACOSX')&&!e.name.endsWith('.txt')&&!e.name.endsWith('.zip'));
 if(nested.length&&!dicoms.length){
  const target=nested.find(e=>/MR_DESS\.zip$/i.test(e.name));
  if(!target)throw Error('Contenedor con ZIP: no se encontró RTKN*_MR_DESS.zip');
  showLoad('Extrayendo el ZIP DESS original del contenedor A…',8);
  const inside=(await unpackMember(buffer,target)).buffer;
  if(gen!==state.loadGeneration)return;
  return loadBuffer(inside,target.name,gen);
 }
 selected=dicoms;
 if(selected.length>2500)throw Error('Se excedió el límite de seguridad de 2500 instancias');
 let total=0;
 for(let i=0;i<selected.length;i++){
  if(gen!==state.loadGeneration)return;
  const e=selected[i];
  if(e.uncompressed>100*1024*1024){errors.push(e.name+': archivo excesivamente grande');continue;}
  try{const raw=await unpackMember(buffer,e);const record=readDicom(raw.buffer,e.name);files.push(record);}catch(ex){if(errors.length<150)errors.push(e.name.split('/').pop()+': '+ex.message);}
  total++;if(i%6===0){showLoad('Leyendo instancias DICOM… '+total+' de '+selected.length,Math.round(total/selected.length*95));await yieldUI();}
 }
 if(gen!==state.loadGeneration)return;
 return commitRecords(files,source,errors,notes,gen);
}
function commitRecords(files,source,errors,notes,gen){
 if(gen!==state.loadGeneration)return;
 if(!files.length)throw Error('No se encontraron instancias DICOM compatibles. '+(errors[0]||''));
 const grouped=new Map();for(const m of files){const k=m.seriesUid||m.description||'sin-serie';if(!grouped.has(k))grouped.set(k,[]);grouped.get(k).push(m);}
 state.series=Array.from(grouped.entries()).map(([uid,items])=>{
  const first=items[0],normal=vecCross(first.iop.slice(0,3),first.iop.slice(3));
  let compatible=items.filter(m=>m.rows===first.rows&&m.columns===first.columns&&m.spacing.every((s,i)=>Math.abs(s-first.spacing[i])<0.002)&&orientCheck(m,first));
  if(compatible.length!==items.length)notes.push(`SERIE: ${items.length-compatible.length} instancias tienen diferente matriz/orientación y fueron excluidas de este stack.`);
  for(const m of compatible)m.projection=dot(normal,m.ipp);
  compatible.sort((a,b)=>a.projection-b.projection||Number(a.instance)-Number(b.instance));
  const dist=compatible.slice(1).map((m,i)=>m.projection-compatible[i].projection);
  const median=dist.slice().sort((a,b)=>a-b)[Math.floor(dist.length/2)]||0;
  if(dist.some(d=>Math.abs(d-median)>0.05))notes.push('Advertencia: espaciamiento irregular; no se habilitan reconstrucciones multiplanares.');
  if(compatible.some(m=>Math.abs(dot(normal,m.ipp)-m.projection)>1e-6))notes.push('Geometría de instancia inconsistente.');
  return{uid,description:first.description||'Serie DICOM',items:compatible,normal,spacingBetween:median};
 }).filter(s=>s.items.length).sort((a,b)=>b.items.length-a.items.length);
 if(!state.series.length)throw Error('Ninguna serie conserva orientación y matriz compatibles');
 state.current=state.series[0];state.index=Math.floor(state.current.items.length/2);state.source=source;
 const active=state.current.items[state.index];
 let sampled=[];for(let i=0;i<active.values.length;i+=17)sampled.push(active.values[i]*active.slope+active.intercept);
 sampled.sort((a,b)=>a-b);state.wlCenter=(sampled[Math.floor(sampled.length*.02)]+sampled[Math.floor(sampled.length*.98)])/2;
 state.wlWidth=Math.max(10,sampled[Math.floor(sampled.length*.98)]-sampled[Math.floor(sampled.length*.02)]);
 state.zoom=1;state.panX=0;state.panY=0;state.imageKey='';state.lastPixels=null;
 notes.unshift(`Importación local · ${files.length} instancias decodificadas en memoria · ${grouped.size} serie(s).`);
 if(files.length===144&&state.current.items.length===144)notes.push('DESS RTKN0668: 144 posiciones geométricas únicas, normal del stack calculada desde ImageOrientationPatient.');
 warningsDisplay(errors,notes);updateControls();render();$('loading').hidden=true;
 toast(`Serie cargada: ${state.current.items.length} cortes reales · sin transmisión externa`);
}
async function loadFiles(fileList){
 const gen=++state.loadGeneration;clean();showLoad('Leyendo archivos de la carpeta…',0);const errors=[],notes=[],records=[];
 try{
  const list=Array.from(fileList).filter(f=>!f.name.startsWith('.')&&!f.name.endsWith('.txt'));
  if(list.length>2500)throw Error('Demasiados archivos en la carpeta');
  for(let i=0;i<list.length;i++){
   if(gen!==state.loadGeneration)return;
   try{records.push(readDicom(await list[i].arrayBuffer(),list[i].name));}catch(e){if(errors.length<150)errors.push(list[i].name+': '+e.message);}
   if(i%6===0){showLoad('Leyendo carpeta… '+(i+1)+' de '+list.length,Math.round((i+1)/list.length*100));await yieldUI();}
  }
  commitRecords(records,'Carpeta local',errors,notes,gen);
 }catch(e){if(gen===state.loadGeneration){$('loading').hidden=true;warningsDisplay([e.message],[]);toast(e.message);}}
}
async function loadZipFile(file){const gen=++state.loadGeneration;clean();showLoad('Abriendo ZIP local…',2);try{const b=await file.arrayBuffer();if(gen!==state.loadGeneration)return;await loadBuffer(b,file.name,gen);}catch(e){if(gen===state.loadGeneration){$('loading').hidden=true;warningsDisplay([e.message],[]);toast(e.message);}}}
async function loadIncluded(){const gen=++state.loadGeneration;clean();showLoad('Leyendo DESS incluida desde localhost…',3);
 try{const controller=new AbortController();loadIncluded.controller=controller;const r=await fetch('datasets/RTKN0668_MR_DESS.zip',{signal:controller.signal,cache:'no-store'});if(!r.ok)throw Error('No se encontró la DESS incluida en el paquete local');const b=await r.arrayBuffer();if(gen!==state.loadGeneration)return;await loadBuffer(b,'RTKN0668_MR_DESS.zip · incluida',gen);}catch(e){if(gen===state.loadGeneration){$('loading').hidden=true;warningsDisplay([e.message],[]);toast(e.message);}}}
function clamp(n,low,high){return Math.max(low,Math.min(high,n));}
function currentFrame(){return state.current?.items[state.index];}
function updateControls(){const active=currentFrame(),has=!!active;
 $('emptyViewer').style.display=has?'none':'flex';$('viewBadge').hidden=!has;
 $('studyTitle').textContent=has?state.current.description:'Sin estudio cargado';$('studySubtitle').textContent=has?`${state.current.items.length} instancias · ${active.modality} · ${state.source}`:'Seleccioná una secuencia para comenzar.';
 $('seriesList').replaceChildren();if(has){for(const s of state.series){const c=document.createElement('div');c.className='seriesCard';const title=document.createElement('strong');title.textContent=s.description;const n=document.createElement('span');n.textContent=`${s.items.length} cortes · ${s.items[0].rows}×${s.items[0].columns}`;c.append(title,n);$('seriesList').append(c);}}
 else $('seriesList').innerHTML='<div class="empty">Todavía no se cargaron imágenes.</div>';
 $('sliceRange').disabled=!has;$('windowRange').disabled=!has;$('levelRange').disabled=!has;
 if(has){$('sliceRange').min=0;$('sliceRange').max=state.current.items.length-1;$('sliceRange').value=state.index;
  const center=state.wlCenter,width=state.wlWidth;
  $('windowRange').max=Math.max(4096,Math.ceil(width*3));$('windowRange').value=clamp(width,1,Number($('windowRange').max));
  $('levelRange').min=-4096;$('levelRange').max=Math.max(4095,Math.ceil(center+width*2));$('levelRange').value=clamp(center,-4096,Number($('levelRange').max));
  $('windowValue').textContent=width.toFixed(0);$('levelValue').textContent=center.toFixed(0);
  $('sliceCurrent').textContent=state.index+1;$('sliceTotal').textContent='/ '+state.current.items.length;
  $('slicePosition').textContent=active.projection.toFixed(2)+' mm';$('frameLabel').textContent='CORTE '+(state.index+1)+' / '+state.current.items.length;
  $('metaMatrix').textContent=active.columns+' × '+active.rows;
  $('metaSpacing').textContent=active.spacing.map(v=>v.toFixed(4)).join(' × ')+' mm';
  $('metaOrientation').textContent=active.iop.map(v=>v.toFixed(3)).join(', ');
  $('metaSyntax').textContent=active.syntax.replace('1.2.840.10008.1.2.1','Explicit VR LE').replace('1.2.840.10008.1.2','Implicit VR LE');
  $('metaCount').textContent=state.current.items.length+' imágenes';$('metaPosition').textContent=active.projection.toFixed(3)+' mm';$('sourceLabel').textContent='FUENTE LOCAL';
 }else{$('sliceCurrent').textContent='—';$('sliceTotal').textContent='/ —';$('slicePosition').textContent='— mm';$('frameLabel').textContent='SIN IMÁGENES';for(let id of ['metaMatrix','metaSpacing','metaOrientation','metaSyntax','metaCount','metaPosition'])$(id).textContent='—';}
 $('brightnessValue').textContent=state.brightness.toFixed(0);$('contrastValue').textContent=state.contrast+'%';
}
function makePixels(frame){const {rows,columns,values,slope,intercept}=frame,output=new ImageData(columns,rows),dst=output.data;
 const lo=state.wlCenter-state.wlWidth/2,width=Math.max(1,state.wlWidth),gain=state.contrast/100,offset=state.brightness/100;
 for(let i=0;i<values.length;i++){const val=values[i]*slope+intercept;let p=clamp((val-lo)/width,0,1);p=clamp((p-.5)*gain+.5+offset,0,1);let gray=Math.round((frame.photo==='MONOCHROME1'?1-p:p)*255);const k=i*4;dst[k]=dst[k+1]=dst[k+2]=gray;dst[k+3]=255;}return output;
}
const canvas=$('scanCanvas'),ctx=canvas.getContext('2d',{alpha:false}),offscreen=document.createElement('canvas'),offctx=offscreen.getContext('2d',{alpha:false});
function render(){const box=canvas.getBoundingClientRect(),ratio=Math.min(devicePixelRatio||1,2),w=Math.max(10,Math.round(box.width*ratio)),h=Math.max(10,Math.round(box.height*ratio));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}
 ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#181b1e';ctx.fillRect(0,0,w,h);
 const frame=currentFrame();if(!frame)return;
 const key=[state.current.uid,state.index,state.wlCenter,state.wlWidth,state.brightness,state.contrast].join('|');
 if(key!==state.imageKey){offscreen.width=frame.columns;offscreen.height=frame.rows;offctx.putImageData(makePixels(frame),0,0);state.imageKey=key;}
 const fit=Math.min(w/frame.columns,h/frame.rows)*.90,scale=fit*state.zoom;
 ctx.save();ctx.translate(w/2+state.panX*ratio,h/2+state.panY*ratio);ctx.scale(scale,scale);ctx.imageSmoothingEnabled=true;ctx.drawImage(offscreen,-frame.columns/2,-frame.rows/2);ctx.restore();
}
function chooseSlice(index){if(!state.current)return;state.index=clamp(Math.round(index),0,state.current.items.length-1);state.imageKey='';updateControls();render();}
function resetView(){state.panX=state.panY=0;state.zoom=1;render();}
$('loadIncluded').onclick=loadIncluded;$('zipButton').onclick=()=>$('zipInput').click();$('folderButton').onclick=()=>$('folderInput').click();
$('zipInput').onchange=e=>{if(e.target.files[0])loadZipFile(e.target.files[0]);e.target.value='';};$('folderInput').onchange=e=>{if(e.target.files.length)loadFiles(e.target.files);e.target.value='';};
$('cancelLoad').onclick=()=>{loadIncluded.controller?.abort();cancelCurrent();clean();toast('Carga cancelada.');};
$('clearButton').onclick=()=>{loadIncluded.controller?.abort();cancelCurrent();clean();warningsDisplay([],['Los datos de la serie se retiraron de la aplicación. La memoria puede liberarse de forma diferida por el navegador.']);toast('Recursos desvinculados de la sesión.');};
$('sliceRange').oninput=e=>chooseSlice(Number(e.target.value));$('prev').onclick=()=>chooseSlice(state.index-1);$('next').onclick=()=>chooseSlice(state.index+1);
$('windowRange').oninput=e=>{state.wlWidth=Number(e.target.value);updateControls();render();};$('levelRange').oninput=e=>{state.wlCenter=Number(e.target.value);updateControls();render();};
$('brightnessRange').oninput=e=>{state.brightness=Number(e.target.value);updateControls();render();};$('contrastRange').oninput=e=>{state.contrast=Number(e.target.value);updateControls();render();};
$('autoWindow').onclick=()=>{const f=currentFrame();if(!f)return;const data=[];for(let i=0;i<f.values.length;i+=17)data.push(f.values[i]*f.slope+f.intercept);data.sort((a,b)=>a-b);let a=data[Math.floor(.02*data.length)],b=data[Math.floor(.98*data.length)];state.wlCenter=(a+b)/2;state.wlWidth=Math.max(1,b-a);updateControls();render();};
$('zoomIn').onclick=()=>{state.zoom=clamp(state.zoom*1.25,.3,10);render();};$('zoomOut').onclick=()=>{state.zoom=clamp(state.zoom/1.25,.3,10);render();};$('fitButton').onclick=resetView;
canvas.addEventListener('wheel',e=>{if(!currentFrame())return;e.preventDefault();if(e.ctrlKey||e.metaKey){state.zoom=clamp(state.zoom*(e.deltaY>0?.9:1.1),.3,10);render();}else chooseSlice(state.index+(e.deltaY>0?1:-1));},{passive:false});
let dragging=false,lastX=0,lastY=0;canvas.onpointerdown=e=>{if(!currentFrame())return;dragging=true;lastX=e.clientX;lastY=e.clientY;canvas.setPointerCapture(e.pointerId);};canvas.onpointermove=e=>{if(!dragging)return;state.panX+=e.clientX-lastX;state.panY+=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;render();};canvas.onpointerup=()=>dragging=false;canvas.onpointercancel=()=>dragging=false;
window.addEventListener('resize',()=>render());document.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowUp'].includes(e.key)){if(currentFrame()){e.preventDefault();chooseSlice(state.index-1);}}else if(['ArrowRight','ArrowDown'].includes(e.key)){if(currentFrame()){e.preventDefault();chooseSlice(state.index+1);}}});
updateControls();render();
