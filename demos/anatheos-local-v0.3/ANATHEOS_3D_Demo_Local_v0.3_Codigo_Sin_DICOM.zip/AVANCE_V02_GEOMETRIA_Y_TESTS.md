# ANATHEOS 3D · Primera reconstrucción volumétrica experimental

## Qué se probó (27/10/2026)

- Estudio público RTKN0668 MR DESS original, SHA256 `1c378e89d3a2e7aa57a1049f1fa91b9278529e544369d1071d4c453073ce951d`.
- 144 DICOM de 384 × 384, Explicit VR LE, IOP/IPP; espaciados aproximados de 0,36458 × 0,36458 × 0,7 mm.
- Construcción y renderizado de textura volumétrica real R8 de 384 × 384 × 144 (21.233.664 bytes ~20,25 MiB), con extensión física aproximada de 140 × 140 × 100,1 mm.
- Ensayo de visualización y rotación mediante fallback CPU sobre la serie completa en Chromium headless, sin errores JS y sin solicitudes de red externa.
- Control interactivo de rotación: 87 vs 94 niveles en región central antes/después y media de intensidad 76,26 vs 73,19; no comparación perceptual clínica.
- Se comprobó retorno a vista 2D y liberación de referencias de la serie.
- Pruebas puras adicionales: validación geométrica de IPP/IOP, dimensiones mm, normal y separación; rechazo de tilt, gaps, IOP inconsistentes, cancelación, mapeo R8.

## Límites y distinciones

- WebGL2 shader y textura GPU están implementados, pero **no probados en navegador con GPU real** en este entorno; el navegador disponible carece de WebGL2.
- La visualización 3D es ray casting directo de intensidades; no segmenta estructuras ni tiene malla. GPU usa R8 (cuantización para display). 2D preserva los valores DICOM nativos.
- No se ha ejecutado comparación geométrica independiente con 3D Slicer. IOP/IPP sirven para orden y proporciones, pero no autorizan etiqueta L/R ni vistas MPR validadas.
- No usar la visualización para diagnóstico.
- Todo dataset/imagen médica queda **fuera del repositorio GitHub público**. Las capturas de RM reales se comparten solo en la entrega privada y no se incluyen en el ZIP de fuentes subido al repo.

## Reproducción Windows

Extraer distribución v0.2, doble clic `INICIAR_ANATHEOS.cmd`, pulsar `Cargar RM DESS incluida` y `Volumen 3D`. Rotar arrastrando; zoom con rueda; variar opacidad/umbral. Volver con `Cortes 2D`. En Windows probar Edge/Chrome. No requiere licencias ni conexiones externas.

## Backups

GitHub: rama experimental y PR sin merge, paquete de código **sin DICOM**. Drive: se preparará segundo respaldo de fuentes. La distribución que incluye DICOM se entrega directamente, no debe incorporarse a GitHub público.
