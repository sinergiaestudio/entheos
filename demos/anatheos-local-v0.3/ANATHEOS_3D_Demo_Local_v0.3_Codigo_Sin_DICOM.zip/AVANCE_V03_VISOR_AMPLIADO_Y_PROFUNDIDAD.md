# ANATHEOS 3D · Demo Local v0.3 · visor ampliado y exploración de profundidades

## Resultado

Basada estrictamente en la **Demo Local v0.2** que Dirección abrió y verificó en Windows. Se conserva el estudio público original `datasets/RTKN0668_MR_DESS.zip` intacto (SHA-256 `1c378e89d3a2e7aa57a1049f1fa91b9278529e544369d1071d4c453073ce951d`, licencia CC BY 4.0, fuente Leeds DOI https://doi.org/10.5518/1834).

### UI v0.3

- Canvas principal ~72dvh en escritorio; sidebar reducido y paneles más compactos.
- Botón **Visor amplio**: oculta sidebar y paneles inferiores, conserva acceso a 2D/3D y botones de vista. `Esc` vuelve al modo normal.
- Botón **Pantalla completa**: API Fullscreen estándar, visor 2D/3D ocupa toda la pantalla y ofrece botón Salir, también antes de cargar archivos.
- Escala inicial del volumen más cercana (`zoom=1.55`, antes 1.22); restablecer rotación devuelve al ángulo y escala estándar. GPU sube tope de framebuffer de 850×570 a 1360×900, condicionado por hardware; durante el arrastre usa previsualización menor para evitar lentitud.
- Profundidad de cortes (5–100 %): recorta posiciones normalizadas `z` en la textura 3D, mediante la misma regla en WebGL2 y CPU. Se conserva el orden espacial IOP/IPP del lector v0.2; **no** es un plano ortogonal remuestreado, segmentación ni máscara anatómica.
- Paleta **grises** o **pseudocolor** de intensidad: no asigna etiquetas histológicas ni anatomía; ambos backends implementan la misma opción. La vista 2D nativa mantiene sus intensidades y valores originales.
- HUD flotante de controles rápidos dentro del canvas 3D, operativo tanto en visor amplio como fullscreen.

### Ensayo ejecutado (local, datos reales)

Chromium `144.0.7559.96` en Linux sin WebGL2: carga del ZIP DESS original completo (144 instancias 384×384), construcción de volumen `384×384×144` (21.233.664 vóxeles, ~20.3 MiB R8), vista CPU, comprobación de tamaños visuales de visor normal (`1296×698 px`), amplio (`1548×800 px`) y pantalla completa (`1580×970 px`). Prueba de estado de controles de recorte y paleta con diferencias observadas en suma de intensidades de imagen y cromaticidad, simulación de giro por mouse, regreso a 2D, liberación, **0 errores de página y 0 solicitudes externas**. Prueba geométrica `node test_volume_core.mjs` PASS.

**Advertencias:** la ruta GPU WebGL2 de las novedades no fue ejecutada aquí: confirmar visualmente sobre Windows con aceleración disponible. La prueba Linux usó CPU, reduciendo resolución interna y reescalando. El render 3D de 8 bits es exploratorio, no diagnóstico. Sin referencia geométrica independiente 3D Slicer, MPR anatómico validado, ni segmentación de meniscos/huesos/cartílago.

La distribución local es únicamente `127.0.0.1`, sin servicios remotos, D1/R2, conexión Site o costos. En GitHub público solo debe guardarse código sin imágenes médicas. Cualquier merge/publicación requiere otra autorización.
